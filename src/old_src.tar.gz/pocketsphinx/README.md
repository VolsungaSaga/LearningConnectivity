A simple ROS wrapper for using Pocketsphinx (via gstreamer) with ROS. See docs here http://wiki.ros.org/pocketsphinx

If installing from source you will need to install the following:
```
sudo apt-get install gstreamer0.10-pocketsphinx
```
