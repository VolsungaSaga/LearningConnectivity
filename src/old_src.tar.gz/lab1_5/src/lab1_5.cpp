//Turtlebot/ROS stuff.
#include "ros/ros.h"
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/Joy.h>
#include <kobuki_msgs/BumperEvent.h>
#include <sensor_msgs/Imu.h>
#include <nav_msgs/Odometry.h>

//For standard C/C++ operations
#include <stdlib.h>
#include <cmath>
//For file operations, to export data for later plotting (in absence of any real-time plotting).
#include <fstream>
#include <iostream>


class autoWanderer{

public:

	//Scale Parameters
	float angularVelScale = 0.5;
	float linearVelScale = 0.5;
	//PID Parameters, Variables
	float Kp=0.2;//0.1
	float Ki=0.02;//0.01
	float Kd=0.005;//0.005
	float u=0;
	float prev_error = 0;
	float reference = 0.3;
	float integral = 0;

	//Bumper Data
	int bumperStatus = 0; 
	int whichBumper = 0;

	//Odom Data
	float actualVelX = 0;	
	float currentXYPosition[2];
	
	int length;
	std::vector<std::vector<float> > map;
	

	//Publisher, Subscriber Objects
	ros::Publisher vel_pub;
	ros::Subscriber bump_sub;
	ros::Subscriber odom_sub;
	ros::Subscriber joy_sub;

	ros::NodeHandle nh;
	autoWanderer();

	//Are we using the joystick?
	bool joystickActivated = false;
 
	geometry_msgs::Twist lastCommand;
	float PIDControl(float reference);



private:
	void bumperCallback(const kobuki_msgs::BumperEvent::ConstPtr& data);
	void odomCallback(const nav_msgs::Odometry::ConstPtr& data);
	void joyCallback(const sensor_msgs::Joy::ConstPtr& joyMsg);



};

autoWanderer::autoWanderer(){
	vel_pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel_mux/input/navi", 1,true);
	bump_sub = nh.subscribe("/mobile_base/events/bumper", 10, &autoWanderer::bumperCallback, this);
	odom_sub = nh.subscribe("/odom", 10, &autoWanderer::odomCallback, this);
	joy_sub = nh.subscribe("/joy", 10, &autoWanderer::joyCallback, this);


	ROS_INFO("Initiated publisher and subscribers. \n");
	
}

float autoWanderer::PIDControl(float reference){
	
	float error= this->reference - this->actualVelX;

	//float acc_Error = 0.05*reference;

	float derivative = (error - this->prev_error);///0.1;

	this->integral += error;// * 0.1;	//0.1 = dt	
	u = Kp*error + Ki * this->integral + Kd*derivative;
	this->prev_error = error;

	//ROS_INFO("Output of PID Controller= %f\n", u);			
	
	return u;
	
	
}


//Controller Config: Mode light is on, switch on top is at 'D'
void autoWanderer::joyCallback(const sensor_msgs::Joy::ConstPtr& data){
	this->lastCommand.linear.x = linearVelScale * data->axes[1]; //linear velocity(m/s);
	this->lastCommand.angular.z = angularVelScale * data->axes[0];//angular velocity(rad/s)

	if(data->buttons[0]) reference = 0.5;
	else if(data->buttons[1]) reference = 0.3;
	else if(data->buttons[2]) reference = 0.0;
	else if(data->buttons[3]) reference = 0.6;

	this->joystickActivated = data->buttons[6] == 1; 

}

void autoWanderer::odomCallback(const nav_msgs::Odometry::ConstPtr& data){
	//Upon receiving an odometry message, we update our actual x velocity.
	//ROS_INFO("Odom Vel X: %f \n", data->twist.twist.linear.x);
	
	this->actualVelX = data->twist.twist.linear.x;	
	
	this->currentXYPosition[0] = data->pose.pose.position.x;
	this->currentXYPosition[1] = data->pose.pose.position.y; 
	ROS_INFO("Position: %.2f, %.2f \n", this->currentXYPosition[0], this->currentXYPosition[1]); 
	
}

void autoWanderer::bumperCallback(const kobuki_msgs::BumperEvent::ConstPtr& data)
	{

	//Upon receiving a bump message, record the state and the bumper number.

	//ROS_INFO("I got bumped! \n");

	this->bumperStatus = data->state;
	this->whichBumper = data->bumper;

	//In order to be sure I'm not just passing addresses, I'm going to deep-copy the current position.
	
	std::vector<float> copyXYPosition;
	copyXYPosition.push_back(this->currentXYPosition[0]);
	copyXYPosition.push_back(this->currentXYPosition[1]);

	//Heuristic: If the position I'm at is close to the previous position I recorded, 
	// do not record the current position as an obstacle, since it's probably the same obstacle.

	ROS_INFO("X,Y Position of Obstacle: %.2f, %.2f", copyXYPosition[0], copyXYPosition[1]);
	map.push_back(copyXYPosition);
	
	/*else if(!map.empty() && (sqrt(pow(copyXYPosition[0] - map.back()[0],2) + pow(copyXYPosition[1] - map.back()[1],2)) > threshold)){
		ROS_INFO("X,Y Position of Obstacle: %.2f, %.2f", copyXYPosition[0], copyXYPosition[1]);
		map.push_back(copyXYPosition);
		 
	}*/
}





int main(int argc, char **argv)
	{
	ros::init(argc, argv, "lab1_2");

	autoWanderer wandererObj = autoWanderer();
	ROS_INFO("Instantiated controller \n.");
	
	ros::Rate loop_rate(100);
	

	geometry_msgs::Twist forwardVel;
	forwardVel.linear.x = 0.1;
	forwardVel.angular.z = 0;

	ROS_INFO("%d\n", ros::ok());
	while(ros::ok()){
		ROS_INFO("%d\n", wandererObj.joystickActivated);
		switch(wandererObj.joystickActivated){
			case true:
				ROS_INFO("Driving Forward \n");
				wandererObj.vel_pub.publish(wandererObj.lastCommand);
				break;

			case false:

				switch(wandererObj.bumperStatus){
					case 0:
				                //wandererObj.vel_pub.publish(forwardVel);
						//ROS_INFO("Reference Value: %f\n", wandererObj.reference);

						forwardVel.linear.x = wandererObj.PIDControl(wandererObj.reference);
						wandererObj.vel_pub.publish(forwardVel);
						
						break;
					case 1:
						//switch(wandererObj.whichBumper){
						int count = 0;
						while(count < 25){
							loop_rate.sleep();
							count +=1;
							ROS_INFO("Backing Up");
							geometry_msgs::Twist vel;
							vel.linear.x = -0.3; //We'll make this a slow speed, irrespective of our reference value
							vel.angular.z = 0;
							wandererObj.vel_pub.publish(vel);
							loop_rate.sleep();	
							ros::spinOnce();
						}			
						
						int randomTurnDuration = (rand() % 20) * 10;

						count = 0;

				                while (count< randomTurnDuration){
							loop_rate.sleep();
							count +=1;
							//ROS_INFO("Turning");
							geometry_msgs::Twist vel;
							vel.linear.x = 0;
							vel.angular.z = 1;
							wandererObj.vel_pub.publish(vel);
							loop_rate.sleep();	
							ros::spinOnce();
				                 }
				
						break;
						}
				break;
				
		}

		ros::spinOnce();
		loop_rate.sleep();
	}

	//Output the bumper data to a file for later plotting by Matlab.
	std::ofstream mapfile;
	mapfile.open("bumperMap.txt");
	for(int i = 0; i < wandererObj.map.size(); i++){
		mapfile << "[" << wandererObj.map[i][0] << "," << wandererObj.map[i][1] << "]\n";
	}

	mapfile.close();
	ROS_INFO("Map Size: %d\n", (int)wandererObj.map.size());

	}

