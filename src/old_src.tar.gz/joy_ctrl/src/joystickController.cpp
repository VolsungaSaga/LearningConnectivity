#include "ros/ros.h"
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/Joy.h>




class joystickController{



public:
	float angularVelScale = 0.5;
	float linearVelScale = 0.5;

	ros::Publisher vel_pub;
	ros::Subscriber joy_sub;
	ros::NodeHandle nh;
	joystickController();

	geometry_msgs::Twist lastCommand;

private:
	void joyCallback(const sensor_msgs::Joy::ConstPtr& joyMsg);

};

joystickController::joystickController(){
	vel_pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel_mux/input/teleop", 1,true);
	joy_sub = nh.subscribe("/joy", 10, &joystickController::joyCallback, this);


	ROS_INFO("Initiated publisher and subscriber. \n");
	
}

void joystickController::joyCallback(const sensor_msgs::Joy::ConstPtr& joyMsg)
	{
	ROS_INFO("Received joystick message \n");

	this->lastCommand.linear.x = linearVelScale * joyMsg->axes[1]; //linear velocity(m/s);
	this->lastCommand.angular.z = angularVelScale * joyMsg->axes[0];//angular velocity(rad/s)
	ROS_INFO("Velocities:\n \t Linear X = %f \n \t Angular Z = %f \n", this->lastCommand.linear.x, this->lastCommand.angular.z);
	}

int main(int argc, char **argv)
	{
	ros::init(argc, argv, "joystick_ctrl");

	joystickController controllerObj = joystickController();
	ROS_INFO("Instantiated controller \n.");
	
	ros::Rate loop_rate(10);

	while(ros::ok()){
		ROS_INFO("Last Command Vel X: %f \nLast Command Ang Z: %f\n", controllerObj.lastCommand.linear.x, controllerObj.lastCommand.angular.z);
		controllerObj.vel_pub.publish(controllerObj.lastCommand);
		ros::spinOnce();
		loop_rate.sleep();
	}
	

	}

