#include "ros/ros.h"
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/Joy.h>

float linear_x = 0.0;
float angular_z = 0.0;

void joyCallback(const sensor_msgs::Joy::ConstPtr& joy)
{
linear_x = 0.5*joy ->axes[1];
angular_z = 2.0*joy ->axes[0];
ROS_INFO("Velocity: linear_x = %f , angular_z = %f.",linear_x,angular_z);
}

int main(int argc, char **argv)
{
ros::init(argc,argc,"lab1_1");
ros::NodeHandle nh;
ros::Publisher vel_pub;
vel_pub = nh.advertise<geometry_msgs::Twist>("cmd_vel_mux/input/navi", 1, true);


ros::Subscriber sub = nh.subscribe("/joy",10,joyCallback)
ros::Rate loop_rate(10);
geometry_msgs::Twist vel;


  

while (ros::ok())
{
vel.linear.x = linear_x;
vel.angular.z = angular_z;
vel_pub.publish(vel);
ros::spinOnce();
loop_rate.sleep();
}
return 0;
}
