#!/usr/bin/env python

import rospy
import math
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan


class stopAtWall:
	
	def __init__(self):
			#PID Stuff
		self.velScale = 1
		self.velKp = 0.3
		self.velKi = 0.1
		self.velKd = 0.05
		self.velIntegral = 0
		self.velPrevError = 0


		self.angScale = 1
		self.angKp = 0.6
		self.angKi = 0
		self.angKd = 0
		self.angIntegral = 0
		self.angPrevError = 0

		#For constant speed
		self.targetVelocity = 1.0

		#Odometry data
		self.currentPosition = [0,0]
		self.currentOrientZ = 0
		self.currentOrientW = 0
		self.actualVelocityX = 0
		self.actualAngularVelocityZ = 0

		#Vision Data - To be completed!
		self.rangeData = []
		


	def odomCallback(self,data):
		self.currentPosition = [data.pose.pose.position.x, data.pose.pose.position.y]
		self.currentOrientZ = data.pose.pose.orientation.z
		self.currentOrientW = data.pose.pose.orientation.w
	
		self.actualVelocityX = data.twist.twist.linear.x
		self.actualAngularVelocityZ = data.twist.twist.angular.z
	
	def visionCallback(self,data):

		self.rangeData = data.ranges[213:426]
	
		#rospy.loginfo("Range Data: {}" .format(rangeData))

	

	def PIDController(self,Kp, Ki, Kd, integral, prevError, measuredVal, refVal):
		error = refVal - measuredVal
		integral += error
		
		derivative = error - prevError
		P = Kp * error
		I = Ki * integral
		D = Kd * derivative
		
		u = P + I + D
		
		prevError = error
		
		return u;

	def angVelRef(self, goalXY, currentXY, currentOrientZ, currentOrientW, scale):
		theta_desired = math.atan2(goalXY[1]-currentXY[1], goalXY[0]-currentXY[0])
		math = theta.atan2(2*currentOrientW * currentOrientZ, currentOrientW**2 -currentOrientZ**2)
		theta_error = theta_desired - theta
		gamma = math.atan2(math.sin(theta_error),math.cos(theta_error))
		return scale * gamma;
		
		
	def velocityRef(self, targetVelocity, velScale):
		return velScale * targetVelocity;


stopAtWallObj = stopAtWall()

rospy.init_node('lab3_1', anonymous=True)
vel_pub = rospy.Publisher('/cmd_vel_mux/input/navi', Twist, queue_size=10)
odom_sub = rospy.Subscriber('/odom',Odometry,stopAtWallObj.odomCallback)
vision_sub = rospy.Subscriber('/scan', LaserScan, stopAtWallObj.visionCallback)
rate = rospy.Rate(10)  # Main loop: 10Hz



while not rospy.is_shutdown():
    velMessage = Twist()
    refVel = stopAtWallObj.velocityRef(stopAtWallObj.targetVelocity, stopAtWallObj.velScale)
    #refVel = stopAtWallObj.velocityRef(1)
    #First, check all the values in the range data.
    print len(stopAtWallObj.rangeData)
    for i in range(len(stopAtWallObj.rangeData)):
        #rospy.loginfo(stopAtWallObj.rangeData[i])
        if (stopAtWallObj.rangeData[i] < 1.0):
	        #rospy.loginfo("Found a value less than zero!\n")
	        refVel = 0
        else:
	        refVel = 0
	        #rospy.loginfo("reaches else")


    #Don't really need angular reference here.

    velU = stopAtWallObj.PIDController(stopAtWallObj.velKp, stopAtWallObj.velKi, stopAtWallObj.velKd, stopAtWallObj.velIntegral, stopAtWallObj.velPrevError, stopAtWallObj.actualVelocityX, refVel)
    velMessage.linear.x = velU
    vel_pub.publish(velMessage)
    rate.sleep()
		
	

		
     


    
