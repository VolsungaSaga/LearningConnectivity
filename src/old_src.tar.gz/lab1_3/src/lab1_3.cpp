#include "ros/ros.h"
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/Joy.h>
#include <kobuki_msgs/BumperEvent.h>
#include <sensor_msgs/Imu.h>
#include <nav_msgs/Odometry.h>
#include <stdlib.h>
#include <cmath>


class autoWanderer{



public:

	//Scale Parameters
	float angularVelScale = 0.5;
	float linearVelScale = 0.5;
	//PID Parameters, Variables
	float Kp=0.5;
	float Ki=0.2;
	float Kd=0.1;
	float u=0;
	float prev_error = 0;
	float reference = 0.3;
	float integral = 0;

	//Bumper Data
	int bumperStatus = 0; 
	int whichBumper = 0;

	//Odom Data
	float actualVelX = 0;	

	ros::Publisher vel_pub;
	ros::Subscriber bump_sub;
	ros::Subscriber odom_sub;

	ros::NodeHandle nh;
	autoWanderer();

	//geometry_msgs::Twist lastCommand;
	float PIDControl(float reference);

private:
	void bumperCallback(const kobuki_msgs::BumperEvent::ConstPtr& data);
	void odomCallback(const nav_msgs::Odometry::ConstPtr& data);



};

autoWanderer::autoWanderer(){
	vel_pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel_mux/input/navi", 1,true);
	bump_sub = nh.subscribe("/mobile_base/events/bumper", 10, &autoWanderer::bumperCallback, this);
	odom_sub = nh.subscribe("/odom", 10, &autoWanderer::odomCallback, this);


	ROS_INFO("Initiated publisher and subscribers. \n");
	
}

float autoWanderer::PIDControl(float reference){
	
	float error= this->reference - this->u;

	float acc_Error = 0.05*reference;

	float derivative = (error - this->prev_error);///0.1;

	this->integral += error;// * 0.1;	//0.1 = dt	
	u = Kp*error + Ki * this->integral + Kd*derivative;
	this->prev_error = error;

	ROS_INFO("Output of PID = %f\n", u);			
	
	return u;
	
	
}


void autoWanderer::odomCallback(const nav_msgs::Odometry::ConstPtr& data){
	//Upon receiving an odometry message, we update our actual x velocity.
	//ROS_INFO("Odom Vel X: %f \n", data->twist.twist.linear.x);
	
	this->actualVelX = data->twist.twist.linear.x;	
	
}

void autoWanderer::bumperCallback(const kobuki_msgs::BumperEvent::ConstPtr& data)
	{

	//Upon receiving a bump message, we will turn 90 degrees to the left.
	//This'll take the form of a while loop until we get the PID implemented.
	ROS_INFO("I got bumped! \n");

	this->bumperStatus = data->state;
	this->whichBumper = data->bumper;

	}



int main(int argc, char **argv)
	{
	ros::init(argc, argv, "lab1_2");

	autoWanderer wandererObj = autoWanderer();
	ROS_INFO("Instantiated controller \n.");
	
	ros::Rate loop_rate(100);
	

	geometry_msgs::Twist forwardVel;
	forwardVel.linear.x = 0.1;
	forwardVel.angular.z = 0;
		

	while(ros::ok()){
		//ROS_INFO("Last Command Vel X: %f \nLast Command Ang Z: %f\n", controllerObj.lastCommand.linear.x, controllerObj.lastCommand.angular.z);
		ROS_INFO("Driving Forward \n");
		//wandererObj.vel_pub.publish(forwardVel);

		switch(wandererObj.bumperStatus){
			case 0:
                                //wandererObj.vel_pub.publish(forwardVel);
				ROS_INFO("Reference Value: %f\n", wandererObj.reference);

				if((abs(wandererObj.u - wandererObj.reference) <= 0.02*wandererObj.reference)){
					ROS_INFO("Switching to 0.5 \n");
					wandererObj.reference = 0.5;				
				}
				if((abs(wandererObj.u - wandererObj.reference) <= 0.02*wandererObj.reference)){
					ROS_INFO("Switching to 0.6 \n");
					wandererObj.reference = 0.6;				
				}


				forwardVel.linear.x = wandererObj.PIDControl(wandererObj.reference);
				wandererObj.vel_pub.publish(forwardVel);
				
				break;
			case 1:
				//switch(wandererObj.whichBumper){
			
				int randomTurnDuration = (rand() % 20) * 10;

				int count = 0;

                                while (count< randomTurnDuration){
					loop_rate.sleep();
					count +=1;
					ROS_INFO("Turning");
					geometry_msgs::Twist vel;
					vel.linear.x = 0;
					vel.angular.z = 1;
					wandererObj.vel_pub.publish(vel);
					//ros::Duration(0.1).sleep();
					loop_rate.sleep();	
					ros::spinOnce();
                                 }
				
				break;
			
	
		}

		ros::spinOnce();
		loop_rate.sleep();
	}
	}

