#!/usr/bin/env python
import rospy
import math
import cv2

from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError


global angKp
global linearKp
global rangeData
global goal_dist
global goal_ang
global follow_dist

global Kp
global Ki
global Kd

global actualVelocityX
global actualAngularVelocityZ

linearKp = 0.3
angKp = 0.5
rangeData = []
goal_dist = 0
goal_ang = 0
follow_dist = 0.8

Kp = 0.2
Ki = 0.01
Kd = 0.01

actualVelocityX = 0
actualAngularVelocityZ = 0

def visionCallback(data):
    global rangeData
    global goal_dist
    global goal_ang
    rangeData = data.ranges[0:640]
    goal_dist = 10
    for i in range(12):
    	if data.ranges[58*i] > 0.5 and data.ranges[58*i] < 10:
    		if goal_dist > data.ranges[58*i]:
    			goal_dist = data.ranges[58*i]
    			goal_ang =  5.5 - i
    print goal_dist,goal_ang

def odomCallback(data):
    global actualVelocityX
    global actualAngularVelocityZ
    actualVelocityX = data.twist.twist.linear.x
    actualAngularVelocityZ = data.twist.twist.angular.z


def PIDController(integral, prevError, measuredVal, refVal):
	global Kp
	global Ki
	global Kd
	error = refVal - measuredVal
	integral += error
	derivative = error - prevError
	P = Kp * error
	I = Ki * integral
	D = Kd * derivative
		
	u = P + I + D
		
	prevError = error



def main():
    global angKp
    global linearKp
    global rangeData
    global goal_dist
    global goal_ang 
    global follow_dist
    vel_pub = rospy.Publisher('/cmd_vel_mux/input/navi', Twist, queue_size=10)
    rospy.init_node('lab3_3', anonymous=True)
    rospy.Subscriber('/scan', LaserScan, visionCallback)
    rospy.Subscriber('/odom', Odometry, odomCallback)
    rate = rospy.Rate(10)  # Main loop: 10Hz

    vel=Twist()
    vel.linear.x=0
    vel.angular.z=0
    while not rospy.is_shutdown():
    	dist = goal_dist - follow_dist	
    	vel.linear.x = linearKp * dist
    	vel.angular.z = -angKp * goal_ang
    	vel_pub.publish(vel)
    	rate.sleep()

      
if __name__ == "__main__":
    main()     