#include "ros/ros.h"
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/Joy.h>
#include <kobuki_msgs/BumperEvent.h>
#include <sensor_msgs/Imu.h>
#include <stdlib.h>


class autoWanderer{



public:
	float angularVelScale = 0.5;
	float linearVelScale = 0.5;

	int bumperStatus = 0; 
	int whichBumper = 0;

	ros::Publisher vel_pub;
	ros::Subscriber bump_sub;

	ros::NodeHandle nh;
	autoWanderer();

	//geometry_msgs::Twist lastCommand;

private:
	void bumperCallback(const kobuki_msgs::BumperEvent::ConstPtr& data);


};

autoWanderer::autoWanderer(){
	vel_pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel_mux/input/navi", 1,true);
	bump_sub = nh.subscribe("/mobile_base/events/bumper", 10, &autoWanderer::bumperCallback, this);


	ROS_INFO("Initiated publisher and subscribers. \n");
	
}




void autoWanderer::bumperCallback(const kobuki_msgs::BumperEvent::ConstPtr& data)
	{

	//Upon receiving a bump message, we will turn 90 degrees to the left.
	//This'll take the form of a while loop until we get the PID implemented.
	ROS_INFO("Received bumper message \n");

	this->bumperStatus = data->state;
	this->whichBumper = data->bumper;

	}

int main(int argc, char **argv)
	{
	ros::init(argc, argv, "lab1_2");

	autoWanderer wandererObj = autoWanderer();
	ROS_INFO("Instantiated controller \n.");
	
	ros::Rate loop_rate(10);
	

	geometry_msgs::Twist forwardVel;
	forwardVel.linear.x = 0.1;
	forwardVel.angular.z = 0;
		

	while(ros::ok()){
		//ROS_INFO("Last Command Vel X: %f \nLast Command Ang Z: %f\n", controllerObj.lastCommand.linear.x, controllerObj.lastCommand.angular.z);
		ROS_INFO("Driving Forward \n");
		//wandererObj.vel_pub.publish(forwardVel);

		switch(wandererObj.bumperStatus){
			case 0:
                                wandererObj.vel_pub.publish(forwardVel);
				break;
			case 1:
				//switch(wandererObj.whichBumper){
			
				int randomTurnDuration = rand() % 20;

				int count = 0;

                                while (count< randomTurnDuration){
					loop_rate.sleep();
					count +=1;
					ROS_INFO("Turning");
					geometry_msgs::Twist vel;
					vel.linear.x = 0;
					vel.angular.z = 1;
					wandererObj.vel_pub.publish(vel);
					//ros::Duration(0.1).sleep();
					loop_rate.sleep();	
					ros::spinOnce();
                                 }
				
				break;
			
	
		}

		ros::spinOnce();
		loop_rate.sleep();
	}
	}

