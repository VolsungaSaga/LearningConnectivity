#!/usr/bin/env python
import rospy
import math
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry


global x_goal
global y_goal
global Max_linear_speed
global Max_angular_speed
global get_inital_pose
global angKp
global linearKp
global x_pose
global y_pose
global orientation_z
global orientation_w
global circle_radius
x_goal = [x/50.0 for x in range(0,628,1)]
y_goal = [x/50.0 for x in range(0,628,1)]
Max_linear_speed = 0.8
Max_angular_speed = 0.5 
get_inital_pose = False
angKp = 1
linearKp = 0.3
x_pose = 0
y_pose = 0
orientation_z = 0
orientation_w = 0
circle_radius = 0.5
def odomCallback(data):  
    global x_pose
    global y_pose
    global orientation_z
    global orientation_w
    x_pose=data.pose.pose.position.x
    y_pose=data.pose.pose.position.y 
    orientation_z=data.pose.pose.orientation.z 
    orientation_w=data.pose.pose.orientation.w 
    #rospy.loginfo("position point:%.2f,%.2f:",x_pose,y_pose)


def main():
    global x_goal
    global y_goal
    global Max_linear_speed
    global Max_angular_speed
    global get_inital_pose
    global angKp
    global linearKp
    global x_pose
    global y_pose
    global orientation_z
    global orientation_w
    global circle_radius
    vel_pub = rospy.Publisher('/cmd_vel_mux/input/navi', Twist, queue_size=10)
    rospy.init_node('lab2_6', anonymous=True)
    rospy.Subscriber('/odom', Odometry, odomCallback)
    rate = rospy.Rate(10)  # Main loop: 10Hz

    vel=Twist()
    vel.linear.x=0
    vel.angular.z=0


    for i in range(len(x_goal)):
        while not rospy.is_shutdown():
            goal_point_x = circle_radius * math.cos(x_goal[i])
            goal_point_y = circle_radius * math.sin(y_goal[i])
	    theta_desired = math.atan2(goal_point_y-y_pose, goal_point_x-x_pose)
            theta = math.atan2(2*orientation_w * orientation_z,orientation_w * orientation_w -orientation_z*orientation_z)
	    theta_error = theta_desired - theta
	    gamma = math.atan2(math.sin(theta_error),math.cos(theta_error))
	    vel.angular.z = angKp * gamma
	    dist_robot_goal = math.sqrt((goal_point_x-x_pose)**2+(goal_point_y-y_pose)**2)
	   # rospy.loginfo("dist,theta,theta_desired,theta_error:%.2f,%.2f,%.2f,%.2f:",dist_robot_goal,theta,theta_desired,gamma)
            if vel.angular.z > Max_angular_speed:
                vel.angular.z = Max_angular_speed;
            elif vel.angular.z < -Max_angular_speed:
                vel.angular.z = -Max_angular_speed;
	    if gamma < 0.2:
                dist_robot_goal = math.sqrt((goal_point_x-x_pose)**2+(goal_point_y-y_pose)**2)
                vel.linear.x = linearKp * dist_robot_goal;
                if vel.linear.x > Max_linear_speed:
                    vel.linear.x = Max_linear_speed
	        elif vel.linear.x < -Max_linear_speed:
		    vel.linear.x = -Max_linear_speed 
	    if dist_robot_goal < 0.2:
               # vel.linear.x = 0
	        #vel.angular.z = 0
		rospy.loginfo("Arrived goal on circle")
		break
	    rospy.loginfo("goal point:%.2f,%.2f,position point:%.2f,%.2f:",goal_point_x,goal_point_y,x_pose,y_pose)
	    #rospy.loginfo("position point:%.2f,%.2f:",x_pose,y_pose)
	    #rospy.loginfo("dist,theta:%.2f,%.2f:",dist_robot_goal,theta_error)
            vel_pub.publish(vel)
            rate.sleep()

      
if __name__ == "__main__":
    main()       
