#!/usr/bin/env python
import rospy
import time
import numpy as np
import csv
from sensor_msgs.msg import Imu
from crazyflie_driver.srv import UpdateParams
from std_srvs.srv import Empty

class PIDTuner():



    def imuSubscriber(self,imu):
        #Store Imu data
        self.linearAccelZ = imu.linear_acceleration.z
        self.linearAccelZ_sample.append(imu.linear_acceleration.z)
        self.angularVelPitch = imu.angular_velocity.y
        self.angularVelPitch_sample.append(imu.angular_velocity.y)

    


    def __init__(self):
        #IMU Data stuff.
        self.linearAccelZ=0
        self.angularVelPitch=0
        self.linearAccelZ_sample = []
        self.angularVelPitch_sample = []

        #This /should/ come from the fly node, but I'll slap this in for now.
        self.thrustTarget = 50000
        self.pitchVelTarget = 0

        self.pitchVarThreshold = 0.05

        self.current_kp = 1
        self.current_kd = 0

        self.mode = 0

        rospy.init_node('pid_tuner', anonymous=False)
        rospy.on_shutdown(self.shutdown)

        rospy.Subscriber('/crazyflie/imu', Imu, self.imuSubscriber)
        r = rospy.Rate(200)
        #################################################################
        #Initialize PID Gains for Pitch
        rospy.loginfo("PD Tuner Initialized.")
        rospy.wait_for_service('/crazyflie/update_params')
        rospy.loginfo("found update_params service")
        self.update_params = rospy.ServiceProxy('/crazyflie/update_params', UpdateParams)#Proxy for pushing parameters to crazyflie server
        time.sleep(2)
        #Wait 1 second for the server to catch up
        rospy.set_param("/crazyflie/pid_rate/pitch_kp", 1)
        self.update_params(["pid_rate/pitch_kp"])
        rospy.set_param("/crazyflie/pid_rate/pitch_kd", 0)
        self.update_params(["pid_rate/pitch_kd"])
        rospy.set_param("/crazyflie/pid_rate/pitch_ki", 0)
        self.update_params(["pid_rate/pitch_ki"])




        while (not rospy.is_shutdown()):   
            rospy.set_param("/crazyflie/pid_rate/pitch_kp", self.current_kp)
            self.update_params(["pid_rate/pitch_kp"])
        
            # #IF Oscillating update kd
            rospy.set_param("/crazyflie/pid_rate/pitch_kd", self.current_kd)
            self.update_params(["pid_rate/pitch_kd"])

            #with open('./gains.csv', 'wb') as f:
            #    writer = csv.writer(f)
            #    data= [self.current_kp, self.current_kd] 
            #    writer.writerows(data)

            time.sleep(2) #wait 1-2 seconds for sampling Imu data


            #Main Logic Goes here
            #Calculate errors and variation
            #Update proportional and/or derivative gains
            squaredErrorSum_pitch = 0
            for pitchVel in self.angularVelPitch_sample:
                squaredErrorSum_pitch += (pitchVel - self.pitchVelTarget)**2
            variancePitchVel = squaredErrorSum_pitch / len(self.angularVelPitch_sample)

            avgThrust = sum(self.linearAccelZ_sample)/len(self.linearAccelZ_sample)

            avgThrustError = abs(self.thrustTarget - avgThrust)


            #linear_z = self.linearAccelZ #sum(self.linearAccelsZ)/len(linearAccelsZ)
            
            if(self.mode == 0):
                if (avgThrust > 9.9 or avgThrust < 9.7):
                    self.current_kp += 100
                else:
                    rospy.loginfo("Changing to mode 1")
                    self.mode = 1
            elif(self.mode == 1):
                self.current_kp += 50
                if(variancePitchVel <= self.pitchVarThreshold):
                    pass
                else:
                    rospy.loginfo("Changing to mode 2")
                    self.mode = 2
            else:
                if (variancePitchVel > self.pitchVarThreshold):
                    self.current_kd += 0.5
                    #self.mode = 0
                else:
                    rospy.loginfo("Variance resolved, in mode 2")
                    self.current_kd = self.current_kd 
                    

            
            rospy.loginfo("kp: %.2f", self.current_kp)
            rospy.loginfo("kd: %.2f", self.current_kd)
            rospy.loginfo("avgThrust: %.2f", avgThrust)
            rospy.loginfo("pitchVelVariance: %.2f", variancePitchVel)
            # while avgThrust < 9.7 or variancePitchVel <= self.pitchVarThreshold:
            #     self.current_kp += 100

            
            rospy.loginfo("mode: %d", self.mode)

            self.linearAccelZ_sample = []
            self.angularVelPitch_sample = []

    def shutdown(self):
        rospy.loginfo("Stopping the pid_tuner...")
        rospy.sleep(1)
 
if __name__ == '__main__':
    #try:
    PIDTuner()
    rospy.spin()
    # except:
    #     rospy.loginfo("pid_tuner node terminated.")
