//Turtlebot/ROS stuff.
#include "ros/ros.h"
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/Joy.h>
#include <kobuki_msgs/BumperEvent.h>
#include <sensor_msgs/Imu.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/Empty.h>

//For standard C/C++ operations
#include <stdlib.h>
#include <cmath>
//For file operations, to export data for later plotting (in absence of any real-time plotting).
#include <fstream>
#include <iostream>


class autoWanderer{

public:

	//Scale Parameters
	float angularVelScale = 1;
	float linearVelScale = 0.5;
	//PID Parameters, Variables
	float velKp=0.2;//0.1
	float velKi=0.01;//0.01
	float velKd=0.010;//0.025

	float angKp=0.6;//0.2;
	float angKi =0.01;
	float angKd = 0.1;//0.01


	float vel_prev_error = 0;
	float vel_integral = 0;

	float ang_prev_error = 0;
	float ang_integral = 0;

	float max_vel = 0.5;
	float max_angVel = 0.5;



	//Odom Data
	float actualVelX = 0;	
	float actualAngularVelZ = 0;
	float currentXYPosition[2];
	float currentHeading;

	//Goal Point

	//float goalX = 1.5;
	//float goalY = 1.5;
	float goalX = 1.5;
	float goalY = 1.5;

	float acceptableGoalDist = 0.05;

	//Position Map
	int length;
	std::vector<std::vector<float> > map;


	//Publisher, Subscriber Objects
	ros::Publisher vel_pub;
	ros::Publisher odomReset_pub;
	ros::Subscriber bump_sub;
	ros::Subscriber odom_sub;


	ros::NodeHandle nh;
	autoWanderer();

	float velocityRef(float goalX, float goalY, float currentX, float currentY, float velScale);
	float angVelRef(float goalX, float goalY, float currentX, float currentY, float currentHeading, float angVelScale);

	float velPIDControl(float reference, float measured_value);
	float angPIDControl(float reference, float measured_value);


private:

	void odomCallback(const nav_msgs::Odometry::ConstPtr& data);




};

autoWanderer::autoWanderer(){
	vel_pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel_mux/input/navi", 1,true);

	odom_sub = nh.subscribe("/odom", 10, &autoWanderer::odomCallback, this);

	odomReset_pub = nh.advertise<std_msgs::Empty>("/commands/reset_odometry", 1, true);

	ROS_INFO("Initiated publisher and subscribers. \n");
	
}

float autoWanderer::velocityRef(float goalX, float goalY, float currentX, float currentY, float velScale){
	float distanceToGoal = sqrt(pow(goalX - currentX,2) + pow(goalY - currentY,2));
	float velocityDesired =	velScale * distanceToGoal;

	if(velocityDesired > this->max_vel){
		velocityDesired = this->max_vel;
	}

	else if(velocityDesired < -this->max_vel){
		velocityDesired = -this->max_vel;
	}

	if(distanceToGoal < acceptableGoalDist){
		velocityDesired = 0;	

	}	


	ROS_INFO("Vel Reference: %.2f\n", velocityDesired);
	return velocityDesired;
	

}

float autoWanderer::angVelRef(float goalX, float goalY, float currentX, float currentY, float currentHeading, float angVelScale){
	float distanceToGoal = sqrt(pow(goalX - currentX,2) + pow(goalY - currentY,2));	

	float dy = goalY - currentY;

	float dx = goalX - currentX;

	float desiredAng = atan2(dy,dx);
	//ROS_INFO("Ang Reference: %.2f\n", desiredAng);	
	float desiredAngVel = (angVelScale * (desiredAng - currentHeading));

	//We must cap the angular velocity, so it doesn't go into a "death spin".
	//if(desiredAngVel > this->max_angVel){
	//	desiredAngVel = this->max_angVel;
	//}

	//else if(desiredAngVel < -this->max_angVel){
	//	desiredAngVel = -this->max_angVel;
	//}
	//ROS_INFO("Ang Reference: %.2f\n", desiredAngVel);

	if(distanceToGoal < acceptableGoalDist){
		desiredAngVel = 0;	

	}
	
	return desiredAngVel;
}

float autoWanderer::velPIDControl(float reference, float measuredVal ){
	

	if(reference < 0.01 && reference > -0.01){
		return 0.0;
	}

	float error= reference - measuredVal;
	//ROS_INFO("Vel Error: %.2f\n", error);

	//float acc_Error = 0.05*reference;

	float derivative = (error - this->vel_prev_error);///0.1;

	this->vel_integral += error;// * 0.1;	//0.1 = dt	
	float vel_u = velKp*error + velKi * this->vel_integral + velKd*derivative;
	this->vel_prev_error = error;

	//ROS_INFO("Output of Vel PID Controller= %f\n", u);	
		
	
	return vel_u;
	
	
}

float autoWanderer::angPIDControl(float reference, float measuredVal){

	if(reference < 0.01 && reference > -0.01){
		return 0.0;
	}
	float error= reference - measuredVal;
	//ROS_INFO("Ang Error: %.2f\n", error);

	//float acc_Error = 0.05*reference;

	float derivative = (error - this->ang_prev_error);///0.1;

	this->ang_integral += error;// * 0.1;	//0.1 = dt	
	float ang_u = angKp*error;//+ angKi * this->ang_integral + angKd*derivative;
	this->ang_prev_error = error;

	//ROS_INFO("Output of Ang PID Controller= %f\n", ang_u);			
	
	return ang_u;
	
	
}




void autoWanderer::odomCallback(const nav_msgs::Odometry::ConstPtr& data){
	//Upon receiving an odometry message, we update our actual x velocity.
	//ROS_INFO("Odom Vel X: %f \n", data->twist.twist.linear.x);
	
	this->actualVelX = data->twist.twist.linear.x;	
	this->actualAngularVelZ = data->twist.twist.angular.z;
	
	this->currentXYPosition[0] = data->pose.pose.position.x;
	this->currentXYPosition[1] = data->pose.pose.position.y; 
	ROS_INFO("Position: %.2f, %.2f \n", this->currentXYPosition[0], this->currentXYPosition[1]); 
	this->currentHeading = data->pose.pose.orientation.z;
	ROS_INFO("Heading: %.2f radians \n", this->currentHeading);
	
	//In order to be sure I'm not just passing addresses, I'm going to deep-copy the current position.
	
	std::vector<float> copyXYPosition;
	copyXYPosition.push_back(this->currentXYPosition[0]);
	copyXYPosition.push_back(this->currentXYPosition[1]);

	//Heuristic: If the position I'm at is close to the previous position I recorded, 
	// do not record the current position as an obstacle, since it's probably the same obstacle.

	//ROS_INFO("X,Y Position of Robot: %.2f, %.2f", copyXYPosition[0], copyXYPosition[1]);
	map.push_back(copyXYPosition);
}






int main(int argc, char **argv)
	{
	ros::init(argc, argv, "lab2_1");

	autoWanderer wandererObj = autoWanderer();
	ROS_INFO("Instantiated controller \n.");
	
	ros::Rate loop_rate(150);

	ROS_INFO("Resetting odometry to Position 0,0, Heading 0 \n");
	std_msgs::Empty emptyMsg;
	wandererObj.odomReset_pub.publish(emptyMsg);
	

	geometry_msgs::Twist movementVelocity;

	ROS_INFO("%d\n", ros::ok());
	while(ros::ok()){
		float vel_desired = wandererObj.velocityRef(wandererObj.goalX, wandererObj.goalY, wandererObj.currentXYPosition[0], wandererObj.currentXYPosition[1], wandererObj.linearVelScale);
		float angVel_desired = wandererObj.angVelRef(wandererObj.goalX, wandererObj.goalY, wandererObj.currentXYPosition[0], wandererObj.currentXYPosition[1], wandererObj.currentHeading, wandererObj.angularVelScale);

		float vel_u = wandererObj.velPIDControl(vel_desired, wandererObj.actualVelX);
		float ang_u = wandererObj.angPIDControl(angVel_desired, wandererObj.actualAngularVelZ);

		movementVelocity.linear.x = vel_u;
		movementVelocity.angular.z = ang_u;

		ROS_INFO("Output of Vel PID Controller= %f\n", vel_u);	
		ROS_INFO("Output of Ang PID Controller= %f\n", ang_u);			

		wandererObj.vel_pub.publish(movementVelocity);
	
		ros::spinOnce();
		loop_rate.sleep();
	}
//Output the bumper data to a file for later plotting by Matlab.
	std::ofstream mapfile;
	mapfile.open("positionMap.txt");
	for(int i = 0; i < wandererObj.map.size(); i++){
		mapfile << "[" << wandererObj.map[i][0] << "," << wandererObj.map[i][1] << "]\n";
	}

	mapfile.close();
	ROS_INFO("Map Size: %d\n", (int)wandererObj.map.size());




	}

