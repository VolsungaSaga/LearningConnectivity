#!/usr/bin/env python
import rospy
import math
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry


global x_goal
global y_goal
global Max_linear_speed
global Max_angular_speed
global get_inital_pose
global angKp
global linearKp
global x_pose
global y_pose
global orientation_z
global orientation_w
global orientation_x
global orientation_y
x_goal = 1.5
y_goal = 1.5
Max_linear_speed = 0.5
Max_angular_speed = 0.5 
get_inital_pose = False
angKp = 0.5
linearKp = 0.2
x_pose = 0
y_pose = 0
orientation_z = 0
orientation_w = 0
orientation_x = 0
orientation_y = 0
def odomCallback(data):  
    global x_pose
    global y_pose
    global orientation_z
    global orientation_w
    global orientation_x
    global orientation_y
    x_pose=data.pose.pose.position.x
    y_pose=data.pose.pose.position.y 
    orientation_z=data.pose.pose.orientation.z 
    orientation_w=data.pose.pose.orientation.w 
    orientation_x = data.pose.pose.orientation.x
    orientation_y = data.pose.pose.orientation.w 
    #rospy.loginfo("x = %f, y = %f, theta = %f", x_pose,y_pose,orientation_z)

def main():
    global x_goal
    global y_goal
    global Max_linear_speed
    global Max_angular_speed
    global get_inital_pose
    global angKp
    global linearKp
    global x_pose
    global y_pose
    global orientation_z
    global orientation_w
    global orientation_x
    global orientation_y
    vel_pub = rospy.Publisher('/cmd_vel_mux/input/navi', Twist, queue_size=10)
    rospy.init_node('lab2_5', anonymous=True)
    rospy.Subscriber('/odom', Odometry, odomCallback)
    rate = rospy.Rate(10)  # Main loop: 10Hz

    vel=Twist()
    vel.linear.x=0
    vel.angular.z=0


    while not rospy.is_shutdown():
        if not get_inital_pose:
            get_inital_pose = True
            goal_point_x = x_pose + x_goal
            goal_point_y = y_pose + y_goal
            x_pose_old = x_pose
            y_pose_old = y_pose
            dist_robot_goal = math.sqrt((goal_point_x-x_pose)**2+(goal_point_y-y_pose)**2)
            theta_error = 0
        else:
            dist_robot_goal = math.sqrt((goal_point_x-x_pose)**2+(goal_point_y-y_pose)**2)
            theta_desired = math.atan2(goal_point_y-y_pose, goal_point_x-x_pose)
            theta = math.atan2(2*orientation_w * orientation_z,orientation_w * orientation_w -orientation_z*orientation_z)
            #theta = math.atan2(2*(orientation_x*orientation_y+orientation_w*orientation_z),orientation_w * orientation_w +orientation_x*orientation_x-orientation_y*orientation_y - orientation_z*orientation_z)
            theta_error = theta_desired - theta
    
        vel.angular.z = angKp * theta_error
        if vel.angular.z > Max_angular_speed:
            vel.angular.z = Max_angular_speed;
        elif vel.angular.z < -Max_angular_speed:
            vel.angular.z = -Max_angular_speed;

        vel.linear.x = linearKp * dist_robot_goal;
        if vel.linear.x > Max_linear_speed:
            vel.linear.x = Max_linear_speed
        elif vel.linear.x < -Max_linear_speed:
            vel.linear.x = -Max_linear_speed 

        if dist_robot_goal < 0.3:
            rospy.loginfo("Arrived!")
            break
        x_pose_old = x_pose
        y_pose_old = y_pose
        rospy.loginfo("goal point:%.2f,%.2f:",goal_point_x,goal_point_y)
        rospy.loginfo("position point:%.2f,%.2f:",x_pose,y_pose)
        rospy.loginfo("dist,theta:%.2f,%.2f:",dist_robot_goal,theta_error)
        vel_pub.publish(vel)
        rate.sleep()

      
if __name__ == "__main__":
    main()       
