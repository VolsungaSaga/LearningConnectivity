#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from kobuki_msgs.msg import SensorState
from kobuki_msgs.msg import BumperEvent

global sensor_r
global sensor_l
global sensor_m
sensor_r = False
sensor_l = False
sensor_m = False

def cliffCallback(data):
    global sensor_r
    global sensor_l
    global sensor_m
    #rospy.loginfo("right cliff = %f", data.bottom[0])   # 1480 - 1500
   #rospy.loginfo("middle cliff = %f", data.bottom[1]) # 1730 - 1850
    #rospy.loginfo("left cliff = %f", data.bottom[2])  # 1580
    if data.bottom[2] <= 1600:
	sensor_l = True
    else:
        sensor_l = False
    if data.bottom[1] <= 1710:
	sensor_m = True
    else:
        sensor_m = False
    if data.bottom[0] <= 1510:#1510
	sensor_r = True
    else:
        sensor_r = False

global bumper_state
bumper_state = 0
def bumperCallback(data):
    global bumper_state
    bumper_state = data.state


def main():
    global sensor_r
    global sensor_l
    global sensor_m
    global bumper_data
    vel_pub = rospy.Publisher('/cmd_vel_mux/input/navi', Twist, queue_size=1)
    rospy.init_node('lab2_line',anonymous = True)
    rospy.Subscriber('/mobile_base/sensors/core', SensorState, cliffCallback)
    rospy.Subscriber('/mobile_base/events/bumper',BumperEvent,bumperCallback)
    rate = rospy.Rate(100)
    vel = Twist()
    speed_com = 3.8 #3
    angle_com = 4.2 #4.5
    vel.linear.x = 0.1
    vel.angular.z = 0.0
    #count_stop = 1000
    while not rospy.is_shutdown():
	count = 50
	if not bumper_state:
	    if (not sensor_r) and (not sensor_l) and  sensor_m:#go straight,follow the line
                vel.linear.x = 0.1 * speed_com
                vel.angular.z = 0.0 * angle_com
	#        count_stop = 1000;
            elif (not sensor_r) and (not sensor_l) and  not (sensor_m):#follow the line
                vel.linear.x = 0.1 * speed_com
                vel.angular.z = 0.0 * angle_com
	#        count_stop -= 1 
       	    elif  sensor_l and (not sensor_r) : #turn left
	#       count_stop = 1000;
	        while count>0 and (not sensor_m):
                    vel.linear.x = 0.05 * speed_com
                    vel.angular.z = 0.8 * angle_com 
                    count -= 1
	    elif  sensor_r and (not sensor_l): #turn right
    	#        count_stop = 1000;
	        while count>0 and (not sensor_m):
                    vel.linear.x = 0.05 * speed_com
                    vel.angular.z = -0.8 * angle_com
                    count -= 1
	else:
	    break
	rospy.loginfo("bumper_state: %.2f", bumper_state)
        vel_pub.publish(vel)
        rate.sleep()

if __name__ == "__main__":
    main()
