#!/usr/bin/env python
import rospy
import math
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan

global x_offset
global y_offset
global Max_linear_speed
global Max_angular_speed
global get_inital_pose
global angKp
global linearKp
global x_pose
global y_pose
global orientation_z
global orientation_w
global orientation_x
global orientation_y
global rangeData
global go_to_goal_state
global x_goal
global y_goal
global turn_right_signal
x_offset = 4
y_offset = 0
Max_linear_speed = 0.5
Max_angular_speed = 0.5 
get_inital_pose = False
angKp = 0.5
linearKp = 0.1
x_pose = 0
y_pose = 0
orientation_z = 0
orientation_w = 0
orientation_x = 0
orientation_y = 0
rangeData = []
go_to_goal_state = True
x_goal = 0
y_goal = 0
turn_right_signal = True
def odomCallback(data):  
    global x_pose
    global y_pose
    global orientation_z
    global orientation_w
    global orientation_x
    global orientation_y
    global x_goal
    global y_goal
    global x_offset
    global y_offset
    global get_inital_pose
    x_pose=data.pose.pose.position.x
    y_pose=data.pose.pose.position.y 
    orientation_z=data.pose.pose.orientation.z 
    orientation_w=data.pose.pose.orientation.w 
    orientation_x = data.pose.pose.orientation.x
    orientation_y = data.pose.pose.orientation.w 
    if not get_inital_pose:
        x_goal = data.pose.pose.position.x + x_offset
        y_goal = data.pose.pose.position.y + y_offset
        get_inital_pose = True
    #print x_pose,y_pose
    #print x_goal,y_goal
    #rospy.loginfo("x = %f, y = %f, theta = %f", x_pose,y_pose,orientation_z)

def visionCallback(data):
    global rangeData
    global go_to_goal_state
    global turn_right_signal
    count = 0
    rangeData = data.ranges[0:640]
    for i in range(256,383):
        if math.isnan(data.ranges[i]):
            count += 1
    if any(data.ranges[i] < 0.8 for i in range(256,383)) or count > 0.6*(382 - 256):
        go_to_goal_state = False
        if sum(data.ranges[0:320]) >= sum(data.ranges[320:640]):
            turn_right_signal = True
        else:
            turn_right_signal = False
            print sum(data.ranges[0:320]),sum(data.ranges[320:640])
    else:
	    go_to_goal_state = True
    
    



def main():
    global x_goal
    global y_goal
    global Max_linear_speed
    global Max_angular_speed
    global get_inital_pose
    global angKp
    global linearKp
    global x_pose
    global y_pose
    global orientation_z
    global orientation_w
    global orientation_x
    global orientation_y
    global rangeData
    global go_to_goal_state
    global turn_right_signal 
    vel_pub = rospy.Publisher('/cmd_vel_mux/input/navi', Twist, queue_size=10)
    rospy.init_node('lab2_5', anonymous=True)
    rospy.Subscriber('/odom', Odometry, odomCallback)
    vision_sub = rospy.Subscriber('/scan', LaserScan, visionCallback)
    rate = rospy.Rate(10)  # Main loop: 10Hz

    vel=Twist()
    vel.linear.x=0
    vel.angular.z=0
    

    # print rangeData
    
    while not rospy.is_shutdown():
        if get_inital_pose:
            vel = Twist()
            #refVel = stopAtWallObj.velocityRef(stopAtWallObj.targetVelocity, stopAtWallObj.velScale)
            #refVel = stopAtWallObj.velocityRef(1)
            #First, check all the values in the range data.
            print go_to_goal_state
            count = 0
            if go_to_goal_state:
            #     #go to goal
                 
                 goal_point_x = x_goal
                 goal_point_y = y_goal
                 theta_desired = math.atan2(goal_point_y-y_pose, goal_point_x-x_pose)
                 theta = math.atan2(2*orientation_w * orientation_z,orientation_w * orientation_w -orientation_z*orientation_z)
                 theta_error = theta_desired - theta
                 gamma = math.atan2(math.sin(theta_error),math.cos(theta_error))
                 vel.angular.z = angKp * gamma
                 dist_robot_goal = math.sqrt((goal_point_x-x_pose)**2+(goal_point_y-y_pose)**2)
                 
                 # rospy.loginfo("dist,theta,theta_desired,theta_error:%.2f,%.2f,%.2f,%.2f:",dist_robot_goal,theta,theta_desired,theta_error)
                 if vel.angular.z > Max_angular_speed:
                     vel.angular.z = Max_angular_speed;
                 elif vel.angular.z < -Max_angular_speed:
                     vel.angular.z = -Max_angular_speed;
                 if gamma < 0.2:
                     dist_robot_goal = math.sqrt((goal_point_x-x_pose)**2+(goal_point_y-y_pose)**2)
                     vel.linear.x = linearKp * dist_robot_goal;
                     if vel.linear.x > Max_linear_speed:
                         vel.linear.x = Max_linear_speed
                     elif vel.linear.x < -Max_linear_speed:
                         vel.linear.x = -Max_linear_speed 
                 if dist_robot_goal < 0.1:
                     vel.linear.x = 0
                     vel.angular.z = 0
                     print "arrived"
                     #print x_pose,y_pose,x_goal,y_goal
                     break
            else:
                print go_to_goal_state
                while  count < 20:
                    vel.linear.x = 0.2
                    if turn_right_signal:                    
                        vel.angular.z = -0.75#left>0,right<0
                    else:
                        vel.angular.z = 0.75
                    vel_pub.publish(vel)
                    rate.sleep()
                    count += 1
            # #print stopAtWallObj.go_to_goal_state 
            vel_pub.publish(vel)
            rate.sleep()

      
if __name__ == "__main__":
    main()       
