#!/usr/bin/env python

import rospy
import math
import numpy as np
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan


class stopAtWall:
	
    def __init__(self):
	
		self.x_goal = 4
		self.y_goal = 0
		self.Max_linear_speed = 0.5
		self.Max_angular_speed = 0.5 
		self.get_inital_pose = False
		self.go_to_goal_state = True

		#PID Stuff
		self.velScale = 1
		self.velKp = 0.3
		self.velKi = 0.1
		self.velKd = 0.05
		self.velIntegral = 0
		self.velPrevError = 0


		self.angScale = 1
		self.angKp = 0.6
		self.angKi = 0
		self.angKd = 0
		self.angIntegral = 0
		self.angPrevError = 0

		#For constant speed
		self.targetVelocity = 1.0

		#Odometry data
		self.currentPositionX = 0
		self.currentPositionY = 0
		self.currentOrientZ = 0
		self.currentOrientW = 0
		self.actualVelocityX = 0
		self.actualAngularVelocityZ = 0

		#Vision Data - To be completed!
		self.rangeData = []
		


    def odomCallback(self, data):
        self.currentPositionX = data.pose.pose.position.x
        self.currentPositionY = data.pose.pose.position.y
        self.currentOrientZ = data.pose.pose.orientation.z
        self.currentOrientW = data.pose.pose.orientation.w
	
        self.actualVelocityX = data.twist.twist.linear.x
        self.actualAngularVelocityZ = data.twist.twist.angular.z
		#rospy.loginfo(self.currentPositionX)
		#rospy.loginfo (self.currentPositionY)
		
		
    def visionCallback(self, data):
        self.rangeData = data.ranges[0:640]#0-127,128-255,256-383,384-511,512-639
        if any(data.ranges[i] < 0.5 for i in range(256,384)):
            self.go_to_goal_state = True
        else:
            self.go_to_goal_state = False
        print data.ranges[256:384]
        print self.go_to_goal_state
        #rospy.loginfo("Range Data: {}" .format(rangeData))



    def PIDController(self,Kp, Ki, Kd, integral, prevError, measuredVal, refVal):
		error = refVal - measuredVal
		integral += error
		
		derivative = error - prevError
		P = Kp * error
		I = Ki * integral
		D = Kd * derivative
		
		u = P + I + D
		
		prevError = error
		
		return u;

    def angVelRef(self, goalXY, currentXY, currentOrientZ, currentOrientW, scale):
		theta_desired = math.atan2(goalXY[1]-currentXY[1], goalXY[0]-currentXY[0])
		math = theta.atan2(2*currentOrientW * currentOrientZ, currentOrientW**2 -currentOrientZ**2)
		theta_error = theta_desired - theta
		gamma = math.atan2(math.sin(theta_error),math.cos(theta_error))
		return scale * gamma;
		
		
    def velocityRef(self, targetVelocity, velScale):
		return velScale * targetVelocity;

    def angVelRef_WF(self, sectorReadings, scale):
		leftHalfEndIndex = len(sectorReadings)/2
		rightHalfEndIndex = len(sectorReadings)

stopAtWallObj = stopAtWall()

rospy.init_node('lab3_1', anonymous=True)
vel_pub = rospy.Publisher('/cmd_vel_mux/input/navi', Twist, queue_size=10)
odom_sub = rospy.Subscriber('/odom',Odometry,stopAtWallObj.odomCallback)
vision_sub = rospy.Subscriber('/scan', LaserScan, stopAtWallObj.visionCallback)
rate = rospy.Rate(10)  # Main loop: 10Hz
num_of_sensorvector = 5
count = 0

while not rospy.is_shutdown():
    vel = Twist()
    refVel = stopAtWallObj.velocityRef(stopAtWallObj.targetVelocity, stopAtWallObj.velScale)
    #refVel = stopAtWallObj.velocityRef(1)
    #First, check all the values in the range data.
   
    #print stopAtWallObj.go_to_goal_state
    
    if stopAtWallObj.go_to_goal_state:
        #go to goal
        goal_point_x = stopAtWallObj.x_goal
        goal_point_y = stopAtWallObj.y_goal
        theta_desired = math.atan2(goal_point_y-stopAtWallObj.currentPositionY, goal_point_x-stopAtWallObj.currentPositionX)
        theta = math.atan2(2*stopAtWallObj.currentOrientW * stopAtWallObj.currentOrientZ,stopAtWallObj.currentOrientW * stopAtWallObj.currentOrientW -stopAtWallObj.currentOrientZ*stopAtWallObj.currentOrientZ)
        theta_error = theta_desired - theta
        gamma = math.atan2(math.sin(theta_error),math.cos(theta_error))
        vel.angular.z = stopAtWallObj.angKp * gamma
        dist_robot_goal = math.sqrt((goal_point_x-stopAtWallObj.currentPositionX)**2+(goal_point_y-stopAtWallObj.currentPositionY)**2)
       # rospy.loginfo("dist,theta,theta_desired,theta_error:%.2f,%.2f,%.2f,%.2f:",dist_robot_goal,theta,theta_desired,theta_error)
        if vel.angular.z > stopAtWallObj.Max_angular_speed:
            vel.angular.z = stopAtWallObj.Max_angular_speed;
        elif vel.angular.z < -stopAtWallObj.Max_angular_speed:
            vel.angular.z = -stopAtWallObj.Max_angular_speed;
        if gamma < 0.2:
            dist_robot_goal = math.sqrt((goal_point_x-stopAtWallObj.currentPositionX)**2+(goal_point_y-stopAtWallObj.currentPositionY)**2)
            vel.linear.x = stopAtWallObj.velKp * dist_robot_goal;
            if vel.linear.x > stopAtWallObj.Max_linear_speed:
                vel.linear.x = stopAtWallObj.Max_linear_speed
            elif vel.linear.x < -stopAtWallObj.Max_linear_speed:
                vel.linear.x = -stopAtWallObj.Max_linear_speed 
        if dist_robot_goal < 0.1:
            vel.linear.x = 0
            vel.angular.z = 0
            #rospy.loginfo("Arrived")
            break
    else:
        while not stopAtWallObj.go_to_goal_state:
            vel.linear.x = 0
            vel.angular.z = 0.5
    #print stopAtWallObj.go_to_goal_state 
    vel_pub.publish(vel)
    rate.sleep()
		

        
