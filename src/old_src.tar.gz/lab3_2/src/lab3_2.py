#!/usr/bin/env python

import rospy
import math
import numpy as np
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan


class stopAtWall:
    
    def __init__(self):
    
        #The goal points will be calculated later based on offset + currentPosition
        self.x_goal = 4
        self.y_goal = 0
        self.Max_linear_speed = 0.5
        self.Max_angular_speed = 1 
        self.get_inital_pose = False
        self.go_to_goal_state = True

        #PID Stuff
        self.velScale = 1
        self.velKp = 0.3
        self.velKi = 0.1
        self.velKd = 0.05
        self.velIntegral = 0
        self.velPrevError = 0


        self.angScale = 1
        self.angKp = 0.6
        self.angKi = 0.0
        self.angKd = 0
        self.angIntegral = 0
        self.angPrevError = 0

        #For constant speed
        self.targetVelocity = 0.5

        #Odometry data
        self.currentPositionX = 0
        self.currentPositionY = 0
        self.currentOrientZ = 0
        self.currentOrientW = 0
        self.actualVelocityX = 0
        self.actualAngularVelocityZ = 0


        #Vision Data
        self.rangeData = []

        self.numSectors = 20
        self.sectorReadings = self.numSectors * [0]
        self.obstDistanceThreshold = 1
        

# -------- Subscriber Callback Functions ------
    def odomCallback(self, data):
        self.currentPositionX = data.pose.pose.position.x
        self.currentPositionY = data.pose.pose.position.y
        self.currentOrientZ = data.pose.pose.orientation.z
        self.currentOrientW = data.pose.pose.orientation.w
    
        self.actualVelocityX = data.twist.twist.linear.x
        self.actualAngularVelocityZ = data.twist.twist.angular.z
        #rospy.loginfo(self.currentPositionX)
        #rospy.loginfo (self.currentPositionY)
   

        
 
    def visionCallback(self, data):
        #rospy.loginfo("----VISION CALLBACK----\n")
        #Establish sector sizes
        sector_size = len(data.ranges)/self.numSectors
        self.sectorReadings = [0.0]*self.numSectors

        #Algorithm: 
        # For each sector of the ranges data, assign the corresponding value in visionArray a value of 1 if there's an obstacle, remains 0 otherwise.
        #   Then, the sector values are weighted according to their distance to the center of the array - central sectors are weighted most, while peripheral sectors are weighted least.
        for sector in range (self.numSectors):
            for pixel in range (sector*sector_size, sector*sector_size + sector_size):
                #rospy.loginfo('pixel: {} value : {}'.format(pixel, data.ranges[pixel]))
                if math.isnan(data.ranges[pixel]):
                    pass
                elif data.ranges[pixel]<self.obstDistanceThreshold:
                    #rospy.loginfo("-----Something seen! -----\n")
                    #rospy.loginfo('pixel: {} value : {}'.format(pixel, data.ranges[pixel]))
                    self.sectorReadings[sector] = 1.
                    break
            if (sector < self.numSectors/2):
                self.sectorReadings[sector] = self.sectorReadings[sector]*(sector+1)/ (self.numSectors/2.)
                #rospy.loginfo('first part of array : {}' .format(sector))
            else:
                self.sectorReadings[sector]  = self.sectorReadings[sector]*(self.numSectors  - (sector))/ (self.numSectors/2.)
                #('second part of array : {}' .format(sector))

    def processing(self, data):

        sector_size = len(data.ranges)/self.numSectors
        self.sectorReadings = [0]*self.numSectors
        for sector in range (self.numSectors):
            for pixel in range (sector*sector_size + pixel, sector*sector_size + sector_size):
                if data.ranges[pixel]<self.obstDistanceThreshold:
                    self.sectorReadings[sector] = 1
                    break
            if (sector < self.numSectors/2):
                self.sectorReadings[sector] = self.sectorReadings[sector]*(sector+1)/ (self.numSectors/2.)
            else:
                self.sectorReadings[sector]  = self.sectorReadings[sector]*(self.numSectors  - (sector))/ (self.numSectors/2.)
        self.sectorReadings = self.sectorReadings



# ------ PID Control Function -------
    def PIDController(self,Kp, Ki, Kd, integral, prevError, measuredVal, refVal):
        error = refVal - measuredVal
        integral += error
        
        derivative = error - prevError
        P = Kp * error
        I = Ki * integral
        D = Kd * derivative
        
        u = P + I + D
        
        prevError = error
        
        return u;

# ------ Reference Value Functions ------
    def angVelRef(self, goalXY, currentXY, currentOrientZ, currentOrientW, scale):
        theta_desired = math.atan2(goalXY[1]-currentXY[1], goalXY[0]-currentXY[0])
        theta = math.atan2(2*currentOrientW * currentOrientZ, currentOrientW**2 -currentOrientZ**2)
        theta_error = theta_desired - theta
        refAng = math.atan2(math.sin(theta_error),math.cos(theta_error))
        return scale * refAng;
        
        
    def velocityRef(self, targetVelocity, velScale):
        return velScale * targetVelocity;

    def angVelRef_WF(self, sectorReadings, scale):
        leftHalfEndIndex = len(sectorReadings)/2
        rightHalfEndIndex = len(sectorReadings)
        turningSum = 0 #Default to straight traveling

        for i in range(leftHalfEndIndex):
            turningSum += sectorReadings[i]
        for i in range(leftHalfEndIndex+1, rightHalfEndIndex):
            turningSum += -sectorReadings[i]

        rospy.loginfo("Turning by: {}".format(turningSum))

        return turningSum * scale;



stopAtWallObj = stopAtWall()

rospy.init_node('lab3_2', anonymous=True)
vel_pub = rospy.Publisher('/cmd_vel_mux/input/navi', Twist, queue_size=10)
odom_sub = rospy.Subscriber('/odom',Odometry,stopAtWallObj.odomCallback)
vision_sub = rospy.Subscriber('/scan', LaserScan, stopAtWallObj.visionCallback)
rate = rospy.Rate(10)  # Main loop: 10Hz
num_of_sensorvector = 5
count = 0

while not rospy.is_shutdown():
    vel = Twist()
    refVel = stopAtWallObj.velocityRef(0, stopAtWallObj.velScale)
    refAng = 0
    #refVel = stopAtWallObj.velocityRef(1)
    #First, check all the values in the range data.
   
    #print stopAtWallObj.go_to_goal_state
    rospy.loginfo(stopAtWallObj.sectorReadings)

    if any(stopAtWallObj.sectorReadings):
        stopAtWallObj.go_to_goal_state = False
    else: 
        stopAtWallObj.go_to_goal_state = True
    
    if stopAtWallObj.go_to_goal_state:
        #Go To Goal State
        goal_point_x = stopAtWallObj.x_goal
        goal_point_y = stopAtWallObj.y_goal
        refAng = stopAtWallObj.angVelRef([goal_point_x,goal_point_y], [stopAtWallObj.currentPositionX, stopAtWallObj.currentPositionY], stopAtWallObj.currentOrientZ, stopAtWallObj.currentOrientW, stopAtWallObj.angScale)

        dist_robot_goal = math.sqrt((goal_point_x-stopAtWallObj.currentPositionX)**2+(goal_point_y-stopAtWallObj.currentPositionY)**2)
       # rospy.loginfo("dist,theta,theta_desired,theta_error:%.2f,%.2f,%.2f,%.2f:",dist_robot_goal,theta,theta_desired,theta_error)

       #Capping of angular speed to maximum values to prevent horrible burnouts.
        if refAng > stopAtWallObj.Max_angular_speed:
            refAng = stopAtWallObj.Max_angular_speed;
        elif refAng < -stopAtWallObj.Max_angular_speed:
            refAng = -stopAtWallObj.Max_angular_speed;
        #If desired turning speed is less than 0.2 (unscaled), then add linear velocity as well.
        if refAng < 0.2:
            refVel = stopAtWallObj.velocityRef(stopAtWallObj.targetVelocity, stopAtWallObj.velScale)

            # if vel.linear.x > stopAtWallObj.Max_linear_speed:
            #     vel.linear.x = stopAtWallObj.Max_linear_speed
            # elif vel.linear.x < -stopAtWallObj.Max_linear_speed:
            #     vel.linear.x = -stopAtWallObj.Max_linear_speed 
        #If we've reached the goal, our velocity must be zero.
        if dist_robot_goal < 0.1:
            refVel = 0
            refAng = 0
            #rospy.loginfo("Arrived")
            break
    else:
        #Wall Following State
            refVel = stopAtWallObj.velocityRef(stopAtWallObj.targetVelocity / 2, stopAtWallObj.velScale)
            refAng = stopAtWallObj.angVelRef_WF(stopAtWallObj.sectorReadings, stopAtWallObj.angScale)

    #print stopAtWallObj.go_to_goal_state 

    vel.linear.x = stopAtWallObj.PIDController(stopAtWallObj.velKp, stopAtWallObj.velKi, stopAtWallObj.velKd, stopAtWallObj.velIntegral, stopAtWallObj.velPrevError, stopAtWallObj.actualAngularVelocityZ, refVel)
    vel.angular.z = stopAtWallObj.PIDController(stopAtWallObj.angKp, stopAtWallObj.angKi,stopAtWallObj.angKd, stopAtWallObj.angIntegral, stopAtWallObj.angPrevError, stopAtWallObj.actualAngularVelocityZ, refAng)


    vel_pub.publish(vel)
    rate.sleep()
        

        
