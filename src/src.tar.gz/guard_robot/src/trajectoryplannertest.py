#!/usr/bin/env python
import rospy
import math
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry


global x_goal
global y_goal
global Max_linear_speed
global Max_angular_speed
global get_inital_pose
global angKp
global linearKp
global x_pose
global y_pose
global orientation_z
global orientation_w
x_goal = [1,1,0,0]
y_goal = [0,1,1,0]
Max_linear_speed = 0.5
Max_angular_speed = 0.5 
get_inital_pose = False
angKp = 1
linearKp = 0.2
x_pose = 0
y_pose = 0
orientation_z = 0
orientation_w = 0

#!/usr/bin/env python
import rospy
import math
import cv2
import numpy
import scipy.cluster.hierarchy as hcluster
import time

from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from nav_msgs.msg import OccupancyGrid
from sensor_msgs.msg import LaserScan
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import actionlib

from Entity import Entity


global angKp
global linearKp
global depthImage
global goal_dist
global goal_ang
global follow_dist

global Kp
global Ki
global Kd

global myPose
myPose = [0,0,0,0]

global actualVelocityX
global actualAngularVelocityZ

global Max_angular_speed
global Max_linear_speed

Max_angular_speed = 0.1
Max_linear_speed = 0.1

linearKp = 0.3
angKp = 0.5
depthImage = None
goal_dist = 0
goal_ang = 0
follow_dist = 0.8

Kp = 0.2
Ki = 0.01
Kd = 0.01

actualVelocityX = 0
actualAngularVelocityZ = 0

#SLAM Stuff - Information Matrix and Vector:
global infoMatrix
global infoVector
global uList


global occGrid
#Covariance matrix of measurements
global Q


#Assumptions about variances (because hell if we're going to calibrate the sensors ourselves).
measVarianceDepth = 0.1
measVarianceOdom = 0.1 
landmarks = [] #To be defined later.

#Image Processing Fields:
global blurryImage
global bluenessImage
global rednessImage
global greennessImage

global depthImage

global blueKeypoints
global redKeypoints
global greenKeypoints

global currentEnemy
global guardList
global waypointList

global bridge

bluenessImage = None
rednessImage = None
greennessImage = None
intenseImage = None
depthImage = None

blueKeypoints = []
redKeypoints = []
greenKeypoints = []

currentEnemy = None
testEnemyList = []

guardList = []
waypointList = []

#Initialize bridge object, for converting ROS images to openCV images and vice versa.
bridge = CvBridge()

global detectorParams 
detectorParams = cv2.SimpleBlobDetector_Params()
detectorParams.filterByInertia = False
detectorParams.filterByConvexity = False
detectorParams.filterByCircularity = False
detectorParams.filterByArea = True
detectorParams.filterByColor = True

detectorParams.minThreshold = 100
detectorParams.maxThreshold = 256

global blobFinder
blobFinder = cv2.SimpleBlobDetector(detectorParams)

global debugMode
debugMode = True
def odomCallback(data):  
    global x_pose
    global y_pose
    global orientation_z
    global orientation_w
    x_pose=data.pose.pose.position.x
    y_pose=data.pose.pose.position.y 
    orientation_z=data.pose.pose.orientation.z 
    orientation_w=data.pose.pose.orientation.w 
    #rospy.loginfo("position point:%.2f,%.2f:",x_pose,y_pose)

def imageCallback(img_rgb):
    global bridge
    global blobFinder

    global bluenessImage
    global rednessImage
    global greennessImage

    global blueKeypoints
    global redKeypoints
    global greenKeypoints

    
    cv_image = bridge.imgmsg_to_cv2(img_rgb, desired_encoding = "bgr8")

    #Preprocessing done!
    cv_image = cv2.GaussianBlur(cv_image, (5,5), 25)


    #Convert to an HSV image.
    img_hsv = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)
    #rospy.loginfo("size of image:{}".format(img_hsv.shape))
    

    #These are the HSV ranges of the color Navy Blue. These will be the Enemy, as jeans are a horrid plague upon the world of fashion.
    #minBlueVals = numpy.array([110,80,30])
    #maxBlueVals = numpy.array([130,255,255])
    minBlueVals = numpy.array([110,150,50],dtype=numpy.uint8)
    maxBlueVals = numpy.array([130,255,255],dtype=numpy.uint8)


    minRedVals = numpy.array([150,150,50],dtype=numpy.uint8)
    maxRedVals = numpy.array([180,255,255],dtype=numpy.uint8)
    #rospy.loginfo ("minRedVals : {} maxRedVals :{}".format(minRedVals, maxRedVals))
    #These are the HSV ranges of the color Green. These will be the Waypoints: things to patrol between.

    minGreenVals = numpy.array([33,80,40],dtype=numpy.uint8)
    maxGreenVals = numpy.array([100,255,255],dtype=numpy.uint8)

    bluMask = cv2.inRange(img_hsv, minBlueVals, maxBlueVals)
    cv_bluenessImage = cv2.bitwise_and(cv_image, cv_image, mask = bluMask)

    redMask = cv2.inRange(img_hsv, minRedVals, maxRedVals)
    cv_rednessImage = cv2.bitwise_and(cv_image, cv_image, mask = redMask)

    greenMask = cv2.inRange(img_hsv, minGreenVals, maxGreenVals)
    cv_greennessImage = cv2.bitwise_and(cv_image, cv_image, mask = greenMask)

    #blobFinderParams = blobFinder.Params()


    blueKeypoints = blobFinder.detect(cv2.bitwise_not(cv_bluenessImage))
    redKeypoints = blobFinder.detect(cv2.bitwise_not(cv_rednessImage))
    greenKeypoints = blobFinder.detect(cv2.bitwise_not(cv_greennessImage))
    return redKeypoints
    #rospy.loginfo("blueKeypoints :{} redKeypoint : {} greenKeypoint :{}".format(len(blueKeypoints), len(redKeypoints), len(greenKeypoints)))
    '''
    if len(blueKeypoints) != 0:
        for keypoint in blueKeypoints:
            pass
            #rospy.loginfo("blueKeypoint {}:{},{}".format(keypoint.pt[0], keypoint.pt[1],len(blueKeypoints)))
            cv2.drawKeypoints(image=cv_bluenessImage, keypoints=blueKeypoints, outImage=cv_bluenessImage, color = [0,0,255])
    elif len(greenKeypoints) != 0:
        for keypoint in greenKeypoints:
            pass
            #rospy.loginfo("greenKeypoint {}:{},{}".format(keypoint.pt[0], keypoint.pt[1],len(greenKeypoints)))
            cv2.drawKeypoints(image=cv_greennessImage, keypoints=greenKeypoints, outImage=cv_greennessImage, color = [0,255,0])

    elif len(redKeypoints) != 0:
        for keypoint in redKeypoints:
            pass
            #rospy.loginfo("redKeypoint {}:{},{}".format(keypoint.pt[0], keypoint.pt[1],len(redKeypoints)))
            cv2.drawKeypoints(image=cv_rednessImage, keypoints=redKeypoints, outImage=cv_rednessImage, color = [255,0,0])

    else:
        rospy.loginfo("nothing detected")
        #rospy.loginfo("Size of Image {}:{}".format(keypoint, keypoint.size))
    
    bluenessImage = bridge.cv2_to_imgmsg(cv_bluenessImage, encoding="bgr8")
    rednessImage = bridge.cv2_to_imgmsg(cv_rednessImage, encoding="bgr8")
    greennessImage = bridge.cv2_to_imgmsg(cv_greennessImage, encoding="bgr8")
    t2 = time.clock()
    rospy.loginfo("Time taken in image processing:{}".format(t2-t1))
    '''



      
def main():
    global angKp
    global linearKp


    global actualVelocityX
    global actualAngularVelocityZ

    global myPose
    global depthImage
    global goal_dist
    global goal_ang 
    global follow_dist

    global bluenessImage
    global rednessImage
    global greennessImage
    global intenseImage

    global blueKeypoints
    global redKeypoints
    global greenKeypoints

    global x_goal
    global y_goal
    global Max_linear_speed
    global Max_angular_speed
    global get_inital_pose
    global angKp
    global linearKp
    global x_pose
    global y_pose
    global orientation_z
    global orientation_w
    vel_pub = rospy.Publisher('/cmd_vel_mux/input/navi', Twist, queue_size=10)
    blueImgPub = rospy.Publisher('/blueImage', Image, queue_size=10)
    redImgPub = rospy.Publisher('/redImage', Image, queue_size=10)
    greenImgPub = rospy.Publisher('/greenImage', Image, queue_size=10)

    rospy.init_node('lab4', anonymous=True)
    rospy.Subscriber('/odom', Odometry, odomCallback)
    rospy.Subscriber('camera/rgb/image_raw', Image, imageCallback)
    rospy.Subscriber('/camera/depth/image_raw', Image, IRCallback)
    rospy.Subscriber('/map', OccupancyGrid, mapCallback)

    rate = rospy.Rate(10)  # Main loop: 10Hz

    vel=Twist()
    vel.linear.x=0
    vel.angular.z=0

    green_num = 0
    green_flag = 0

    blue_flag = 0
    blue_num = 0

    for i in range(4):
        while not rospy.is_shutdown():
            goal_point_x = x_goal[i]
            goal_point_y = y_goal[i]
            theta_desired = math.atan2(goal_point_y-y_pose, goal_point_x-x_pose)
            theta = math.atan2(2*orientation_w * orientation_z,orientation_w * orientation_w -orientation_z*orientation_z)
            theta_error = theta_desired - theta
            theta_error = math.atan2(math.sin(theta_error),math.cos(theta_error))
            vel.angular.z = angKp * theta_error
            dist_robot_goal = math.sqrt((goal_point_x-x_pose)**2+(goal_point_y-y_pose)**2)
            rospy.loginfo("dist,theta,theta_desired,theta_error:%.2f,%.2f,%.2f,%.2f:",dist_robot_goal,theta,theta_desired,theta_error)
            if vel.angular.z > Max_angular_speed:
                vel.angular.z = Max_angular_speed;
            elif vel.angular.z < -Max_angular_speed:
                vel.angular.z = -Max_angular_speed;
            if theta_error < 0.2:
                dist_robot_goal = math.sqrt((goal_point_x-x_pose)**2+(goal_point_y-y_pose)**2)
                vel.linear.x = linearKp * dist_robot_goal;
                if vel.linear.x > Max_linear_speed:
                    vel.linear.x = Max_linear_speed
                elif vel.linear.x < -Max_linear_speed:
                    vel.linear.x = -Max_linear_speed 
            if dist_robot_goal < 0.1 and i != 3:
                rospy.loginfo("arrived goal point %.2f",i)
                break
            if dist_robot_goal < 0.1 and i == 3:
                vel.linear.x = 0
                vel.angular.z = 0
                rospy.loginfo("Arrived")
                break
            #rospy.loginfo("goal point:%.2f,%.2f:",goal_point_x,goal_point_y)
            #rospy.loginfo("position point:%.2f,%.2f:",x_pose,y_pose)
            #rospy.loginfo("dist,theta:%.2f,%.2f:",dist_robot_goal,theta_error)
            

            vel_pub.publish(vel)
            rate.sleep()
        rate.sleep()

    vel_pub.publish(Twist())
      
if __name__ == "__main__":
    main()    
