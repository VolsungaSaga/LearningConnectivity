import roslib; roslib.load_manifest('pocketsphinx')
import rospy
import math

from geometry_msgs.msg import Twist
from std_msgs.msg import String

global voice_msg 
voice_msg=''
def speechCb(data):  
	global voice_msg 
	voice_msg = data.data
	print voice_msg
    #rospy.loginfo(data.data)

def main():
	global voice_msg

	vel_pub = rospy.Publisher('/cmd_vel_mux/input/navi', Twist, queue_size=10)
	rospy.init_node('lab2_5', anonymous=True)
	rospy.Subscriber('recognizer/output', String,speechCb)
	rate = rospy.Rate(10)  # Main loop: 10Hz
	vel=Twist()
	vel.linear.x=0
	vel.angular.z=0
	while not rospy.is_shutdown():
		vel_pub.publish(vel)
		rate.sleep()
		#print '----'
		#voice_msg = ''

      
if __name__ == "__main__":
    main()       