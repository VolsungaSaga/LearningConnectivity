import os
os.system("/home/robot6/catkin_ws/src/guard_robot/media/doggy.wav")